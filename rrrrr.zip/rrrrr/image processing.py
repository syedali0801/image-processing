from PIL import Image, ImageDraw
import cv2
import numpy as np
import os
import matplotlib.pyplot as plt

# Define image paths
image_path = r'C:\Users\HP\Desktop\image 4.jpg'  # Input image path
output_directory = r'C:\Users\HP\Desktop\rrrrr'  # Output directory for results

# Ensure the output directory exists
os.makedirs(output_directory, exist_ok=True)

# Load the pre-trained Haar Cascade face detector from OpenCV
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Step 1: Load the image
image = Image.open(image_path)

# Display the original image
plt.imshow(image)
plt.title("Original Image")
plt.axis('off')
plt.show()

# Convert PIL Image to OpenCV format
opencv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

# Step 2: Detect faces in the image
gray_opencv_image = cv2.cvtColor(opencv_image, cv2.COLOR_BGR2GRAY)
faces = face_cascade.detectMultiScale(gray_opencv_image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

# Highlight faces
highlighted_image = opencv_image.copy()
for (x, y, w, h) in faces:
    cv2.rectangle(highlighted_image, (x, y), (x + w, y + h), (0, 0, 255), 2)  # Red rectangle

# Convert back to PIL Image format for consistency
highlighted_image_pil = Image.fromarray(cv2.cvtColor(highlighted_image, cv2.COLOR_BGR2RGB))

highlighted_image_path = os.path.join(output_directory, 'highlighted_image.jpg')
highlighted_image_pil.save(highlighted_image_path)
print(f"Highlighted image saved at {highlighted_image_path}")

# Display highlighted image
plt.imshow(highlighted_image_pil)
plt.title("Highlighted Image with Faces Detected")
plt.axis('off')
plt.show()

# Step 3: Convert to grayscale
gray_image = image.convert('L')
gray_image_path = os.path.join(output_directory, 'gray_image.jpg')
gray_image.save(gray_image_path)
print(f"Grayscale image saved at {gray_image_path}")

# Display grayscale image
plt.imshow(gray_image, cmap='gray')
plt.title("Grayscale Image")
plt.axis('off')
plt.show()

# Step 4: Apply edge detection
gray_np = np.array(gray_image)
edges = cv2.Canny(gray_np, 100, 200)
edges_image_path = os.path.join(output_directory, 'edges_image.jpg')
cv2.imwrite(edges_image_path, edges)
print(f"Edges image saved at {edges_image_path}")

# Display edges image
plt.imshow(edges, cmap='gray')
plt.title("Edges Image")
plt.axis('off')
plt.show()

